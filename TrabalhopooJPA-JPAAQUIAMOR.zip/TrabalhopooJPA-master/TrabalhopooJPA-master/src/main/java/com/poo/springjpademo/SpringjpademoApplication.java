package com.poo.springjpademo;

import com.poo.springjpademo.entity.*;
import com.poo.springjpademo.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Sort;


@SpringBootApplication
public class SpringjpademoApplication {

	private static final Logger log = LoggerFactory.getLogger(SpringjpademoApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(SpringjpademoApplication.class, args);
	}

	@Bean
	public CommandLineRunner demo(ProfessorRepository professorRepository, DisciplinaRepository disciplinaRepository, HorarioRepository horarioRepository, SalaRepository salaRepository, TurmaRepository turmaRepository) {

		return (args) -> {
			log.info("Adicionando dados sala");
			salaRepository.save(new Sala("320"));
			salaRepository.save(new Sala("321"));
			salaRepository.save(new Sala("322"));
			salaRepository.save(new Sala("323"));
			var s1 = salaRepository.findByNomeSala("320");
			var s2 = salaRepository.findByNomeSala("321");
			var s3 = salaRepository.findByNomeSala("322");
			var s4 = salaRepository.findByNomeSala("323");

			log.info("Adicionando dados horario");
			horarioRepository.save(new Horario(s1.get(),"19:00","19:50"));
			horarioRepository.save(new Horario(s2.get(),"19:50","20:40"));
			horarioRepository.save(new Horario(s3.get(),"20:40","21:30"));
			horarioRepository.save(new Horario(s4.get(),"21:30","22:20"));
			var h1 = horarioRepository.findById(1L);
			var h2 = horarioRepository.findById(2L);
			var h3 = horarioRepository.findById(3L);
			var h4 = horarioRepository.findById(4L);


			log.info("Adicionando dados professor");
			professorRepository.save(new Professor("Leanderson"));
			professorRepository.save(new Professor("Paulo"));
			professorRepository.save(new Professor("Vanessa"));
			professorRepository.save(new Professor("Chaiene"));
			var p1 = professorRepository.findById(1L);
			var p2 = professorRepository.findById(2L);
			var p3 = professorRepository.findById(3L);
			var p4 = professorRepository.findById(4L);

			log.info("Adicionando dados disciplina");
			disciplinaRepository.save(new Disciplina("POO",p1.get(),h1.get()));
			disciplinaRepository.save(new Disciplina("SOP",p2.get(),h2.get()));
			disciplinaRepository.save(new Disciplina("ETI",p3.get(),h3.get()));
			disciplinaRepository.save(new Disciplina("REQ",p4.get(),h4.get()));
			var d1 = disciplinaRepository.findByNomeDisciplina("POO");
			var d2 = disciplinaRepository.findByNomeDisciplina("SOP");
			var d3 = disciplinaRepository.findByNomeDisciplina("ETI");
			var d4 = disciplinaRepository.findByNomeDisciplina("REQ");


			turmaRepository.save(new Turma("Engenharia de Software", d1.get()));
			turmaRepository.save(new Turma("Engenharia de Software", d2.get()));
			turmaRepository.save(new Turma("Sistemas da Informação", d3.get()));
			turmaRepository.save(new Turma("Sistemas da Informação", d4.get()));

			log.info("-------------------------------");
			log.info(" findAll");
			for(var p : professorRepository.findAll()){
				log.info(p.toString());
			}

			log.info("-------------------------------");
			log.info(" findAllOrderByNomeDesc");
			for(var p : professorRepository.findAll(Sort.by(Sort.Direction.DESC,"nome"))){
				log.info(p.toString());
			}
			log.info("-------------------------------");
			log.info(" findById");
			var p = professorRepository.findById(1l);
			log.info(p.toString());
			log.info("-------------------------------");
			log.info(" findByINome");
			 p = professorRepository.findByNomeProfessor("Vanessa");
			log.info(p.toString());

			var p1 = professorRepository.findById(1L); //busca professor id 1
			var p2 = professorRepository.findById(2L); //busca professor id 2
			var h1 = horarioRepository.findByAula(1L); //busca aula 1
			var h2 = horarioRepository.findByAula(2L); //busca aula 2
			var h3 = horarioRepository.findByAula(3L); //busca aula 3
			var h4 = horarioRepository.findByAula(4L); //busca aula 4
			disciplinaRepository.save(new Disciplina("Poo 1", p1.get(),h1.get()));
			disciplinaRepository.save(new Disciplina("Poo 2", p1.get(),h2.get()));
			disciplinaRepository.save(new Disciplina("IA", p2.get(),h2.get()));
			disciplinaRepository.save(new Disciplina("Redes", p2.get(),h4.get()));
			log.info("-------------------------------");

			log.info(" Disciplinas");
			for(var d : disciplinaRepository.findAll()){
				log.info(d.toString());
			}
			p = professorRepository.findById(3L);
			log.info("-------------------------------");
			log.info(" Disciplinas do professor paulo");
			for(var d : disciplinaRepository.findAllByProfessor(p.get())){
				log.info(d.toString());
			}
		};
	}

}
